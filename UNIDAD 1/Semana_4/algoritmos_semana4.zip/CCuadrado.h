#pragma once
#include <iostream>
using namespace std;
using namespace System;

class CCuadrado {
private:
	int posx;
	int posy;
	int dx;
	int dy;
	char car;
	int color;
public:
	CCuadrado();
	~CCuadrado();
	//getters y setter
	int getPosx();
	int getPosy();
	int getDx();
	int getDy();
	char getCar();
	int getColor();

	void setPosx(int posx);
	void setPosy(int posy);
	void setDx(int dx);
	void setDy(int dy);
	void setCar(char car);
	void setColor(int color);
	//metodos
	void colorear();
	void borrar();
	void mover(int anchoC, int largoC);
	void dibujar();
};

CCuadrado::CCuadrado(){
	this->car = 219;
	this->posx = 0;
	this->posy = 0;
	this->dx = 1;
	this->dy = 1;
	//asignar color
	colorear();
}
CCuadrado::~CCuadrado(){}
//getters y setter
int CCuadrado::getPosx() { return this->posx; }
int CCuadrado::getPosy() { return this->posy; }
int CCuadrado::getDx() { return this->dx; }
int CCuadrado::getDy() { return this->dy; }
char CCuadrado::getCar() { return this->car; }
int CCuadrado::getColor() { return this->color; }

void CCuadrado::setPosx(int posx) { this->posx = posx; }
void CCuadrado::setPosy(int posy) { this->posy = posy; }
void CCuadrado::setDx(int dx) { this->dx = dx; }
void CCuadrado::setDy(int dy) { this->dy = dy; }
void CCuadrado::setCar(char car) { this->car = car; }
void CCuadrado::setColor(int color) { this->color = color; }
//metodos
void CCuadrado::colorear(){
	Random x;
	color = x.Next(1, 16);
	_sleep(0);
}
void CCuadrado::borrar(){
	Console::SetCursorPosition(posx, posy);
	cout << " ";
	Console::SetCursorPosition(posx + 1, posy);
	cout << " ";
}
void CCuadrado::mover(int anchoC, int largoC){
	//movimiento a la derecha
	if (posy == 0 && (posx + 2 > 0 && posx + 2 < anchoC)) {
		posx += dx;
	}
	//movimiento hacia abajo
	if ((posx == anchoC - 2) && (posy + 2 > 0 && posy + 2 <= largoC)) {
		posy += dy;
	}
	//movimiento a la izquierda
	if ((posy == largoC - 2) && (posx > 0 && posx + 2 <= anchoC)) {
		posx -= dx;
	}
	//movimiento hacia arriba
	if (posx == 0 && (posy > 0 && posy + 2 <= largoC)) {
		posy -= 1;
	}
}
void CCuadrado::dibujar(){
	Console::SetCursorPosition(posx, posy);
	Console::ForegroundColor = ConsoleColor(color);
	cout << car;
	Console::SetCursorPosition(posx + 1, posy);
	Console::ForegroundColor = ConsoleColor(color);
	cout << car;
}