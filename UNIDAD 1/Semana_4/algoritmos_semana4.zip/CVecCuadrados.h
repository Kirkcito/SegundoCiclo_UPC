#pragma once
#include "CCuadrado.h"

class CVecCuadrados {
private:
	CCuadrado** arreglo;
	int N;
public:
	CVecCuadrados();
	~CVecCuadrados();
	int getN();
	void AgregarCuadrado(CCuadrado* objeto);
	void MostrarCuadrado(int anchoC, int largoC);
	void CambiarColores();
	void deleteCuadrado(int indice);
};

CVecCuadrados::CVecCuadrados(){
	this->arreglo = nullptr;
	this->N = 0;
}
CVecCuadrados::~CVecCuadrados(){}
int CVecCuadrados::getN() { return this->N; }
void CVecCuadrados::AgregarCuadrado(CCuadrado* objeto){
	CCuadrado** temporal = new CCuadrado * [N + 1];

	if (temporal != nullptr) {
		for (int i = 0; i < N; i++) {
			temporal[i] = arreglo[i];
		}
	}
	temporal[N] = objeto;

	if (arreglo != nullptr) {
		delete[] arreglo;
	}
	arreglo = temporal;
	N++;
}
void CVecCuadrados::MostrarCuadrado(int anchoC, int largoC){
	for (int i = 0; i < N; i++) {
		arreglo[i]->borrar();
		arreglo[i]->mover(anchoC, largoC);
		arreglo[i]->dibujar();
	}
}
void CVecCuadrados::CambiarColores(){
	for (int i = 0; i < N; i++) {
		arreglo[i]->colorear();
	}
}
void CVecCuadrados::deleteCuadrado(int indice){
	CCuadrado** temporal = new CCuadrado*[N - 1];
	if (temporal != nullptr) {
		for (int i = 0; i < N; i++) {
			arreglo[indice]->borrar();

			temporal[i] = arreglo[i + 1];
		}
	}

	if (arreglo != nullptr) {
		delete[] arreglo;
	}
	arreglo = temporal;
	N--;
}