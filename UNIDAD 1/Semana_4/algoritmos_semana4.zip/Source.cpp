#include <conio.h>
#include "CVecCuadrados.h"

int main() {
	int anchoC = Console::BufferWidth;
	int largoC = Console::BufferHeight;
	Console::CursorVisible = false;
	char tecla;

	CVecCuadrados* objVecCuadrado = new CVecCuadrados();
	CCuadrado* objCuadrado;

	//_sleep(2000);
	while (true) {
		if (_kbhit()) {
			tecla = getch();
			tecla = toupper(tecla);
			if (tecla == 'A') {
				objCuadrado = new CCuadrado();
				objVecCuadrado->AgregarCuadrado(objCuadrado);
			}
			if (tecla == 'E') {
				objVecCuadrado->deleteCuadrado(0);
			}
			if (tecla == 'C') {
				objVecCuadrado->CambiarColores();
			}
		}
		if (objVecCuadrado->getN() > 0) {
			objVecCuadrado->MostrarCuadrado(anchoC, largoC);
		}
		_sleep(100);
	}

	

	getch();
	return 0;
}