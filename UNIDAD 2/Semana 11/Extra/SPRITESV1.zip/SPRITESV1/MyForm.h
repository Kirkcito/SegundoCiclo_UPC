#pragma once

namespace SPRITESV1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Timer^ timer1;
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	protected:
	private: System::ComponentModel::IContainer^ components;

		   int indice;
	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm::typeid));
			this->timer1 = (gcnew System::Windows::Forms::Timer(this->components));
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// timer1
			// 
			this->timer1->Enabled = true;
			this->timer1->Tick += gcnew System::EventHandler(this, &MyForm::timer1_Tick);
			// 
			// pictureBox1
			// 
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(605, 244);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(262, 63);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::AutoSize;
			this->pictureBox1->TabIndex = 0;
			this->pictureBox1->TabStop = false;
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(893, 426);
			this->Controls->Add(this->pictureBox1);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void timer1_Tick(System::Object^ sender, System::EventArgs^ e) {
		/*int anchoimagen = this->pictureBox1->Width / 4;
		int altoimagen = this->pictureBox1->Height;

		Graphics^ canvas = this->CreateGraphics();

		canvas->Clear(Color::White);

		Drawing::Rectangle porcionAUsar = Drawing::Rectangle(anchoimagen * indice, 0, anchoimagen, altoimagen);

		canvas->DrawImage(pictureBox1->Image, 50, 50, porcionAUsar, GraphicsUnit::Pixel);

		//
		indice++;

		if (indice >= 4)indice = 0;

		*/
		//con transp�rencia
	/*	int anchoimagen = this->pictureBox1->Width / 4;
		int altoimagen = this->pictureBox1->Height;

		Graphics^ canvas = this->CreateGraphics();

		canvas->Clear(Color::White);

		Bitmap^ imgTransparente = gcnew Bitmap(this->pictureBox1->Image);

		imgTransparente->MakeTransparent(imgTransparente->GetPixel(10, 2));

		Drawing::Rectangle porcionAUsar = Drawing::Rectangle(anchoimagen * indice, 0, anchoimagen, altoimagen);

		canvas->DrawImage(imgTransparente, 50, 50, porcionAUsar, GraphicsUnit::Pixel);

		indice++;

		if (indice >= 4)indice = 0;
		*/

	/*	Graphics^ g = this->CreateGraphics();
		g->Clear(Color::White);
		for (int i = 0; i < 1000; i++)
		{
			if (i % 2 == 0)
				g->FillRectangle(Brushes::Red, i * 2, i * 2, 50, 50);  
			else
				g->FillRectangle(Brushes::Lime, i * 2, i * 2, 50, 50);
		}
		delete g;
		*/

		Graphics^ g = this->CreateGraphics();

		// Reservamos un espacio para poner el Buffer
		BufferedGraphicsContext^ espacioBuffer = BufferedGraphicsManager::Current;

		// Creamos un canvas dentro del espacio del buffer utilizando el canvas
	// del formulario
		BufferedGraphics^ buffer = espacioBuffer->Allocate(g, this->ClientRectangle);

		// A partir de aqu� todo los dibujos se deben realizar en el Canvas del Buffer
	// buffer->Graphics
		/*buffer->Graphics->Clear(Color::White);
		for (int i = 0; i < 100; i++)
			buffer->Graphics->FillRectangle((i % 2 == 0) ? Brushes::Red : Brushes::Lime, i * 2, i * 2, 50, 50);

		// Pasamos el buffer terminado al canvas visible  
		 
		buffer->Render(g);
// Limpiamos la memoria reservada
		delete buffer;
		delete espacioBuffer;
		delete g;
		*/

		//crear un canvas
		Graphics^ canvas = this->CreateGraphics();
		//Asegurarse que la ventana no esta minimizada
		if (canvas->VisibleClipBounds.Width > 0 && canvas->VisibleClipBounds.Height > 0)
		{
			// crear una imagen
			Bitmap^ imagen = gcnew Bitmap(canvas->VisibleClipBounds.Width, canvas->VisibleClipBounds.Height);
			//crear un canvas para pintar en la imagen
			Graphics^ CanvasImagen = Graphics::FromImage(imagen);

			// todo se pinta ahora en el canvas de la imagen  CanvasImagen->Clear(Color::Black);
			for (int i = 0; i < 100; i++)
				CanvasImagen->FillRectangle((i % 2 == 0) ? Brushes::Red : Brushes::Lime, i * 2, i * 2, 50, 50);

			// este seria el "render" pintar la imagen en pantalla  
			canvas->DrawImage(imagen, 0, 0);
			delete CanvasImagen;  delete imagen;
		}
		delete canvas;


	}
	private: System::Void MyForm_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	};
}
